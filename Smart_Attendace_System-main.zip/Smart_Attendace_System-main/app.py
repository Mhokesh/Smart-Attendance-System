import numpy as np
import pandas as pd
import face_recognition
import cv2
import os
import smtplib
import threading
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime
from flask import Flask, render_template, Response
import signal
import sys

app = Flask(__name__)

# Load students.csv
students_file = "students.csv"
students = pd.read_csv(students_file)

# Prepare student names and their face encodings
student_names = students['Name'].values
student_face_encodings = []

for name in student_names:
    image_path = os.path.join('student_images', f'{name}.jpg')  # Assumes student images are stored in a 'student_images' folder
    if os.path.exists(image_path):
        image = face_recognition.load_image_file(image_path)
        encoding = face_recognition.face_encodings(image)
        if encoding:
            student_face_encodings.append(encoding[0])  # Add the encoding for the student
        else:
            student_face_encodings.append(None)  # If no face encoding is found, append None
    else:
        student_face_encodings.append(None)  # No image found for this student

# Extract staff email
staff_email = students.loc[students['role'] == 'staff', 'Email'].values
staff_email = staff_email[0] if len(staff_email) > 0 else None

# Email credentials
sender_email = "projectsas13@gmail.com"
sender_password = "pqwy zzgp tynv qswv"

# Attendance DataFrame (Global)
attendance = pd.DataFrame(columns=["Name", "Date", "Time", "Status"])

# Lock for thread safety in attendance updates
attendance_lock = threading.Lock()

@app.route('/')
def home():
    # Pass the path of the logo image to the template
    logo_path = 'pics/logo.png'  # Update with your actual logo path
    return render_template('upload1.html', logo_path=logo_path)

@app.route('/index')
def index():
    return render_template('index1.html')

def send_attendance_to_staff():
    """Send attendance sheet to the staff after 1 minute."""
    if staff_email:
        time.sleep(60)  # Wait 1 minute before sending the email
        try:
            print(f"Sending attendance to {staff_email}")

            # Save the attendance to Excel
            filename = "Attendance.xlsx"
            attendance.to_excel(filename, index=False)  # Save the attendance DataFrame as an Excel file
            
            # Check if the file was saved successfully
            if os.path.exists(filename):
                print(f"Attendance file saved successfully as {filename}")
            else:
                print(f"Failed to save the attendance file.")

            # Create email message
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['To'] = staff_email
            msg['Subject'] = "Attendance Report"
            body = "Please find the attached attendance report for your subject."
            msg.attach(MIMEText(body, 'plain'))

            # Attach the attendance file
            with open(filename, "rb") as attachment:
                part = MIMEBase("application", "octet-stream")
                part.set_payload(attachment.read())
            encoders.encode_base64(part)
            part.add_header(
                "Content-Disposition",
                f"attachment; filename={filename}",
            )
            msg.attach(part)

            # Send email
            with smtplib.SMTP("smtp.gmail.com", 587) as server:
                server.starttls()
                server.login(sender_email, sender_password)
                server.send_message(msg)

            print(f"Attendance sheet sent to {staff_email}")
        except Exception as e:
            print(f"Failed to send attendance sheet to staff: {e}")
    else:
        print("Staff email not provided. Skipping email.")

# Start a thread to send attendance after 1 minute
def start_sending_attendance():
    threading.Thread(target=send_attendance_to_staff).start()

def update_attendance(name, attendance_df):
    """Thread-safe function to update the attendance DataFrame."""
    with attendance_lock:
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        current_date = now.strftime("%Y-%m-%d")
        status = "Present"
        
        # Append new attendance entry using pd.concat
        attendance_df = pd.concat([attendance_df, pd.DataFrame([{"Name": name, "Date": current_date, "Time": current_time, "Status": status}])], ignore_index=True)
        print(f"Updated attendance for {name}: {current_date} {current_time}")
        # Save the updated attendance to Excel after each update
        save_attendance_to_excel(attendance_df)
        return attendance_df

def save_attendance_to_excel(attendance_df):
    """Save attendance DataFrame to Excel."""
    try:
        # Save the updated DataFrame to Excel
        filename = "Attendance.xlsx"
        attendance_df.to_excel(filename, index=False)
        print(f"Attendance saved to {filename}")
    except Exception as e:
        print(f"Error saving attendance to Excel: {e}")

def send_email_to_parent(parent_email, student_name, date_time):
    """Send a confirmation email to the parent's email."""
    if parent_email:
        try:
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['To'] = parent_email
            msg['Subject'] = "Attendance Confirmation"
            
            body = f"Attendance has been marked for {student_name} on {date_time}."
            msg.attach(MIMEText(body, 'plain'))

            # Send email
            with smtplib.SMTP("smtp.gmail.com", 587) as server:
                server.starttls()
                server.login(sender_email, sender_password)
                server.send_message(msg)
            
            print(f"Attendance confirmation sent to parent: {parent_email}")
        except Exception as e:
            print(f"Failed to send confirmation to parent: {e}")

# Modify the gen function to send the confirmation email when a student's attendance is marked
def gen():
    path = "images"
    images = []
    classNames = []
    names = set()
    myList = os.listdir(path)

    for cl in myList:
        curImg = cv2.imread(f'{path}/{cl}')
        images.append(curImg)
        classNames.append(os.path.splitext(cl)[0])

    def findEncodings(images):
        encodeList = []
        for img in images:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            encode = face_recognition.face_encodings(img)[0]
            encodeList.append(encode)
        return encodeList  

    encodeListKnown = findEncodings(images)

    cap = cv2.VideoCapture(0)
    frame_count = 0  # Frame counter to skip frames

    while True:
        success, img = cap.read()
        frame_count += 1
        if frame_count % 5 != 0:  # Process every 5th frame
            continue

        imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25)
        imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)

        facesCurFrame = face_recognition.face_locations(imgS)
        encodesCurFrame = face_recognition.face_encodings(imgS, facesCurFrame)

        for encodeFace, faceLoc in zip(encodesCurFrame, facesCurFrame):
            matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
            faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)
            matchIndex = np.argmin(faceDis)

            if matches[matchIndex]:
                name = classNames[matchIndex].upper()
                y1, x2, y2, x1 = faceLoc
                y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
                cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.rectangle(img, (x1, y2 - 35), (x2, y2), (0, 255, 0), cv2.FILLED)
                cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)

                if name not in names:
                    names.add(name)

                    # Update attendance
                    current_time = datetime.now().strftime("%H:%M:%S")
                    current_date = datetime.now().strftime("%Y-%m-%d")
                    date_time = f"{current_date} {current_time}"

                    # Update attendance DataFrame
                    global attendance  # Use the global attendance variable
                    attendance = update_attendance(name, attendance)
                    
                    # Send attendance confirmation to parent
                    parent_email = students.loc[students['Name'].str.upper() == name, 'parents mail'].values
                    if len(parent_email) > 0:
                        threading.Thread(target=send_email_to_parent, args=(parent_email[0], name, date_time)).start()

        # Display the resulting image
        ret, jpeg = cv2.imencode('.jpg', img)
        if ret:
            frame = jpeg.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')

@app.route('/video_feed')
def video_feed():
    return Response(gen(), mimetype='multipart/x-mixed-replace; boundary=frame')

# Signal handler for application shutdown
def handle_shutdown(signal, frame):
    print("\nShutting down the application gracefully...")
    try:
        cv2.destroyAllWindows()
        print("Released all resources and windows.")
    except Exception as e:
        print(f"Error during cleanup: {e}")
    sys.exit(0)

# Register signal handlers
signal.signal(signal.SIGINT, handle_shutdown)
signal.signal(signal.SIGTERM, handle_shutdown)

if __name__ == "__main__":
    start_sending_attendance()
    app.run(debug=True)
